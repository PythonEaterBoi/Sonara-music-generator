/* ------------------------------------------------------------------
   SONARA · player — global audio playback, generation pipeline,
   session library (localStorage), WAV export, shared analyser.
-------------------------------------------------------------------*/

import {
  ReactNode,
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Analysis, Song } from "@/lib/audio/core";
import { ComposeOpts, composeSong } from "@/lib/audio/compose";
import { renderSong } from "@/lib/audio/synth";
import { encodeWav } from "@/lib/audio/wav";
import { makeCover } from "@/lib/audio/cover";

/* -------------------- module-level audio singletons -------------------- */

let audioCtx: AudioContext | null = null;
let volGain: GainNode | null = null;
let sharedAnalyser: AnalyserNode | null = null;

function ensureCtx(): AudioContext {
  if (!audioCtx) {
    const Ctor: typeof AudioContext =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    audioCtx = new Ctor();
    volGain = audioCtx.createGain();
    volGain.gain.value = 0.85;
    sharedAnalyser = audioCtx.createAnalyser();
    sharedAnalyser.fftSize = 512;
    sharedAnalyser.smoothingTimeConstant = 0.82;
    volGain.connect(sharedAnalyser);
    sharedAnalyser.connect(audioCtx.destination);
  }
  return audioCtx;
}

export function getSharedAnalyser(): AnalyserNode | null {
  return sharedAnalyser;
}
export function ensureAudio(): AudioContext {
  return ensureCtx();
}

/* ------------------------------ types ------------------------------ */

export interface LibraryItem {
  id: string;
  song: Song;
  peaks: number[];
  cover: string;
  prompt: string;
  brightness: number;
  energy: number;
  createdAt: number;
}

export type PlayerStatus = "idle" | "working" | "ready";

interface PlayerValue {
  status: PlayerStatus;
  song: Song | null;
  analysis: Analysis | null;
  peaks: number[];
  cover: string;
  currentId: string | null;
  progress: number;
  logs: string[];
  isPlaying: boolean;
  time: number;
  duration: number;
  volume: number;
  library: LibraryItem[];
  generate: (opts: ComposeOpts & { brightness: number }) => Promise<void>;
  toggle: () => void;
  seekFrac: (f: number) => void;
  setVolume: (v: number) => void;
  playItem: (id: string) => Promise<void>;
  removeItem: (id: string) => void;
  downloadWav: () => void;
}

const Ctx = createContext<PlayerValue | null>(null);

const LIB_KEY = "sonara:library:v1";
const VOL_KEY = "sonara:vol";
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export const formatTime = (s: number) => {
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
};

function loadLibrary(): LibraryItem[] {
  try {
    const raw = localStorage.getItem(LIB_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw) as LibraryItem[];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

/* ------------------------------ provider ------------------------------ */

export function PlayerProvider({ children }: { children: ReactNode }) {
  const [status, setStatus] = useState<PlayerStatus>("idle");
  const [song, setSong] = useState<Song | null>(null);
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [peaks, setPeaks] = useState<number[]>([]);
  const [cover, setCover] = useState("");
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(() => {
    const v = parseFloat(localStorage.getItem(VOL_KEY) ?? "0.85");
    return Number.isFinite(v) ? v : 0.85;
  });
  const [library, setLibrary] = useState<LibraryItem[]>(() => loadLibrary());

  const bufferRef = useRef<AudioBuffer | null>(null);
  const srcRef = useRef<AudioBufferSourceNode | null>(null);
  const startedAtRef = useRef(0);
  const offsetRef = useRef(0);
  const rafRef = useRef(0);
  const playingRef = useRef(false);
  const brightnessRef = useRef(0.5);

  useEffect(() => {
    try {
      localStorage.setItem(LIB_KEY, JSON.stringify(library.slice(0, 12)));
    } catch {
      /* storage full — drop oldest */
      try {
        localStorage.setItem(LIB_KEY, JSON.stringify(library.slice(0, 6)));
      } catch {
        /* ignore */
      }
    }
  }, [library]);

  const stopSource = useCallback(() => {
    if (srcRef.current) {
      try {
        srcRef.current.onended = null;
        srcRef.current.stop(0);
      } catch {
        /* already stopped */
      }
      srcRef.current.disconnect();
      srcRef.current = null;
    }
    playingRef.current = false;
  }, []);

  const startAt = useCallback(
    (offset: number) => {
      const ctx = ensureCtx();
      const buf = bufferRef.current;
      if (!buf || !volGain) return;
      void ctx.resume();
      stopSource();
      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.connect(volGain);
      const dur = buf.duration - 2.2; // tail trim
      src.start(0, Math.max(0, Math.min(offset, dur)));
      srcRef.current = src;
      startedAtRef.current = ctx.currentTime;
      offsetRef.current = offset;
      playingRef.current = true;
      setIsPlaying(true);
      src.onended = () => {
        if (playingRef.current && srcRef.current === src) {
          playingRef.current = false;
          setIsPlaying(false);
          offsetRef.current = 0;
          setTime(0);
        }
      };
    },
    [stopSource]
  );

  /* rAF clock */
  useEffect(() => {
    const loop = () => {
      if (playingRef.current && audioCtx && bufferRef.current) {
        const t =
          audioCtx.currentTime - startedAtRef.current + offsetRef.current;
        const maxT = bufferRef.current.duration - 2.2;
        setTime(Math.min(t, maxT));
      }
      rafRef.current = requestAnimationFrame(loop);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  const toggle = useCallback(() => {
    if (!bufferRef.current) return;
    if (playingRef.current) {
      const t = audioCtx ? audioCtx.currentTime - startedAtRef.current + offsetRef.current : 0;
      offsetRef.current = t;
      setTime(t);
      stopSource();
      setIsPlaying(false);
    } else {
      const maxT = bufferRef.current.duration - 2.2;
      startAt(offsetRef.current >= maxT - 0.05 ? 0 : offsetRef.current);
    }
  }, [startAt, stopSource]);

  const seekFrac = useCallback(
    (f: number) => {
      const buf = bufferRef.current;
      if (!buf) return;
      const maxT = buf.duration - 2.2;
      const t = Math.max(0, Math.min(f, 1)) * maxT;
      if (playingRef.current) startAt(t);
      else {
        offsetRef.current = t;
        setTime(t);
      }
    },
    [startAt]
  );

  const setVolume = useCallback((v: number) => {
    setVolumeState(v);
    localStorage.setItem(VOL_KEY, String(v));
    ensureCtx();
    if (volGain && audioCtx) volGain.gain.setTargetAtTime(v, audioCtx.currentTime, 0.03);
  }, []);

  /* ------------------------ generation pipeline ------------------------ */
  const generate = useCallback(
    async (opts: ComposeOpts & { brightness: number }) => {
      if (status === "working") return;
      // unlock audio ASAP inside the user's gesture window
      ensureCtx();
      if (audioCtx && audioCtx.state === "suspended") void audioCtx.resume();
      stopSource();
      setIsPlaying(false);
      setStatus("working");
      setProgress(0);
      setLogs([]);
      brightnessRef.current = opts.brightness;
      const push = (l: string) => setLogs((prev) => [...prev, l]);

      try {
        push("> parsing prompt semantics…");
        await sleep(420);
        const { song: composed, analysis: ana } = composeSong(opts);
        setAnalysis(ana);
        push(`> detected style · ${ana.tags.map((t) => t.label.toLowerCase()).join(" · ") || "auto"}`);
        await sleep(380);
        push(`> key ${ana.root !== null ? "locked" : "selected"} · tempo ${composed.bpm} bpm · ${composed.bars} bars`);
        push("> composing harmonic progression…");
        await sleep(340);
        push("> writing melody, bassline & drum patterns…");
        await sleep(340);
        const noteCount =
          composed.pad.length + composed.bass.length + composed.lead.length + composed.arp.length + composed.drums.length;
        push(`> ${noteCount} events committed · synthesizing…`);
        const { buffer, peaks: pk } = await renderSong(
          composed,
          { brightness: opts.brightness },
          (p) => setProgress(p)
        );
        push("> mastering · soft-clip · normalize −0.9 dBFS");
        await sleep(300);
        push("> ready — press play");

        stopSource();
        bufferRef.current = buffer;
        offsetRef.current = 0;
        setSong(composed);
        setPeaks(pk);
        setDuration(composed.duration);
        setTime(0);
        setCover(makeCover(composed.seed, composed.style));
        const id = `${composed.seed.toString(36)}-${Date.now().toString(36)}`;
        setCurrentId(id);
        setLibrary((prev) =>
          [
            {
              id,
              song: composed,
              peaks: pk,
              cover: makeCover(composed.seed, composed.style),
              prompt: opts.prompt,
              brightness: opts.brightness,
              energy: opts.energy,
              createdAt: Date.now(),
            },
            ...prev.filter((p) => p.song.seed !== composed.seed),
          ].slice(0, 12)
        );
        setStatus("ready");
        setProgress(1);
        startAt(0);
      } catch (err) {
        console.error(err);
        push("> render failed — please retry");
        setStatus("idle");
      }
    },
    [startAt, status, stopSource]
  );

  const playItem = useCallback(
    async (id: string) => {
      const item = library.find((l) => l.id === id);
      if (!item || status === "working") return;
      if (currentId === id && bufferRef.current) {
        toggle();
        return;
      }
      stopSource();
      setIsPlaying(false);
      setStatus("working");
      setLogs(["> restoring session · re-synthesizing…"]);
      setProgress(0.15);
      setSong(item.song);
      setPeaks(item.peaks);
      setCover(item.cover);
      setDuration(item.song.duration);
      setTime(0);
      offsetRef.current = 0;
      setCurrentId(id);
      brightnessRef.current = item.brightness;
      try {
        const { buffer } = await renderSong(
          item.song,
          { brightness: item.brightness },
          (p) => setProgress(0.15 + p * 0.85)
        );
        bufferRef.current = buffer;
        setStatus("ready");
        startAt(0);
      } catch (e) {
        console.error(e);
        setStatus("ready");
      }
    },
    [currentId, library, startAt, status, stopSource, toggle]
  );

  const removeItem = useCallback((id: string) => {
    setLibrary((prev) => prev.filter((l) => l.id !== id));
  }, []);

  const downloadWav = useCallback(() => {
    const buf = bufferRef.current;
    const s = song;
    if (!buf || !s) return;
    const blob = encodeWav(buf);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sonara_${s.title.toLowerCase().replace(/[^a-z0-9]+/g, "-")}_${s.bpm}bpm.wav`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
  }, [song]);

  const value = useMemo<PlayerValue>(
    () => ({
      status,
      song,
      analysis,
      peaks,
      cover,
      currentId,
      progress,
      logs,
      isPlaying,
      time,
      duration,
      volume,
      library,
      generate,
      toggle,
      seekFrac,
      setVolume,
      playItem,
      removeItem,
      downloadWav,
    }),
    [
      status, song, analysis, peaks, cover, currentId, progress, logs, isPlaying,
      time, duration, volume, library, generate, toggle, seekFrac, setVolume,
      playItem, removeItem, downloadWav,
    ]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function usePlayer(): PlayerValue {
  const v = useContext(Ctx);
  if (!v) throw new Error("usePlayer must be used within PlayerProvider");
  return v;
}
